import java.util.Arrays;
import java.util.Scanner;

public class MarsRoverOperation {
    /**
     * The Mars Rover accepts instructions to move in the form of "LFFFRFFFRRFFF"
     * where "L" => rotate 90 degrees left
     *  	 "R" => rotate 90 degrees right
     *    	 "F" => move forward one unit
     *
     *
     * Example:
     * 		 For input "FFRF", the result should be [1,2].
     */

    /**
     * This method moves the Mars Rover, according to the instructions passed in the input.
     *
     * @param input Instructions in the format "FFLR"
     * @return final position of the robot in the format [1,2]
     */
    public String move(String input) {
        int[] position = new int[]{0,0};
        int x=0, y=0;

        int countRotate = 0;
        for(int i=0; i<input.length(); i++)
        {
            char c = input.charAt(i);

            if(c == 'R')
                countRotate++;

            if(c == 'L')
                countRotate--;

            if(c == 'F')
            {
                if(Math.abs(countRotate)%4 == 0)
                    y++;

                if(Math.abs(countRotate)%4 == 2)
                    y--;

                if(countRotate > 0 && countRotate%4 == 1)
                    x++;

                if(countRotate > 0 && countRotate%4 == 3)
                    x--;

                if(countRotate < 0 && Math.abs(countRotate)%4 == 1)
                    x--;

                if(countRotate < 0 && Math.abs(countRotate)%4 == 3)
                    x++;
            }

        }
        position[0] = x;
        position[1] = y;
        return Arrays.toString(position);


    }

    /**
     * Your application also accepts the move input as a command-line argument.
     */
    public static void main(String argv[]) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Input: ");
        String input = scanner.nextLine();
//        String regx = ".[^LRF]";
//        boolean checkInput = !input.matches(regx);
//
//        while(checkInput == false)
//        {
//            scanner = new Scanner(System.in);
//            System.out.println("Input error, please Input again: ");
//            input = scanner.nextLine();
//            checkInput = !input.matches(regx);
//        }


        MarsRoverOperation marsRoverOperation = new MarsRoverOperation();

        System.out.print("Output: " + marsRoverOperation.move(input));



    }
}
