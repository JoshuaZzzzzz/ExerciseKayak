module.exports = class PreFlightCheck {
    constructor(readyForBoarding, remainingPassengersCount, onRunway){
        this.readyForBoarding = readyForBoarding;
        this.remainingPassengersCount = remainingPassengersCount;
        this.onRunway = onRunway;
    }

    array = [];

    addProcedure(proceed, abort){
        PreFlightCheck.call(this, proceed,abort);
        array.push(function() { func(1); });
    }
    execute( readyForBoarding, remainingPassengersCount,onRunway ){
        try {
            while (array.length){
                var fnc=array.splice(0,1)[0]
                fnc();
            }
            alert ("done"); 
            
        } catch (errpr) {
            
        }
    }

    proceed(){
        return readyForBoarding,remainingPassengersCount,onRunway;
    }
    abort(words){
        console.log(words);
    }
    
  };