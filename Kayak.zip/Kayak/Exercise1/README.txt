In this exercise you’ll build the KAYAK header in CSS/HTML.

Folder Structure

Exercise 1
        |-- specs
                |-- header-specs
                        - index.html
        |-- your solution
                |-- assets
                        - chevron_down.svg
                        - K_large.png
                        - K_small.png
                        - user.svg
                - index.html
                - style.css

Specifications

All of the design specifications are located in Exercise 1 > specs > header-specs > index.html

Opening this file will show you a tool used for gathering layout specifications for a design. Clicking on various elements within the design will expose size, color, and spacing information for each element.

Implementation Instructions

Your implementation will go in Exercise 1 > your solution > index.html & Exercise 1 > your solution > style.css. The Exercise 1 > assets folder contains all images and icons needed to produce the design.